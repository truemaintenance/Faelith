
const response = document.getElementById('response');

if ('webkitSpeechRecognition' in window) {
    const recognition = new webkitSpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = false;
    recognition.lang = 'en-US';
    recognition.start();

    recognition.onresult = function(event) {
        const transcript = event.results[event.results.length - 1][0].transcript.trim().toLowerCase();
        if (transcript.includes("wake up faelith")) {
            response.textContent = "I'm listening, baby.";
        }
    };

    recognition.onerror = function(event) {
        response.textContent = "Error occurred in recognition: " + event.error;
    };
} else {
    response.textContent = "Speech Recognition not supported in this browser.";
}
