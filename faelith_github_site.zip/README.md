# Faelith GitHub Site
This is a simple voice-enabled prototype of Faelith.