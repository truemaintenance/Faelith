import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';
import data from '../data/chartData.json';

export default function BarCharts() {
  return (
    <BarChart width={300} height={200} data={data} className="mx-auto">
      <CartesianGrid strokeDasharray="3 3" />
      <XAxis dataKey="name" />
      <YAxis />
      <Tooltip />
      <Bar dataKey="units" />
    </BarChart>
  );
}
