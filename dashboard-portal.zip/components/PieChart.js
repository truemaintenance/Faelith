import React from 'react';
import { PieChart, Pie, Cell, Tooltip } from 'recharts';

export default function PieChart({ data }) {
  const chartData = data.map(p => ({ name: p.name, value: p.status === 'Live' ? 1 : p.status === 'In Progress' ? 0.5 : 0.2 }));
  const COLORS = ['#8884d8', '#82ca9d', '#ffc658'];
  return (
    <PieChart width={200} height={200} className="mx-auto">
      <Pie data={chartData} dataKey="value" nameKey="name" outerRadius={80} label>
        {chartData.map((entry, index) => (
          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
        ))}
      </Pie>
      <Tooltip />
    </PieChart>
  );
}
