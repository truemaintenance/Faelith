// Install dependencies: recharts

import React from 'react';
import Link from 'next/link';
import dynamic from 'next/dynamic';
import data from '../data/personalities.json';
const BarChartComp = dynamic(() => import('../components/BarCharts'), { ssr: false });

export default function Home() {
  return (
    <div className="p-4 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4 text-center">Unified Dashboard Portal</h1>
      <BarChartComp />
      <div className="grid grid-cols-1 gap-4 mt-6">
        {data.map(personality => (
          <Link key={personality.key} href={`/${personality.key}`}>
            <a className="p-4 rounded-2xl shadow-md bg-white hover:bg-gray-100 transition">
              <h2 className="text-xl font-semibold">{personality.name}</h2>
              <p className="text-sm text-gray-600">Status: {personality.status}</p>
            </a>
          </Link>
        ))}
      </div>
    </div>
  );
}
