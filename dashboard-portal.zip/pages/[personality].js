import React from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import data from '../data/personalities.json';
import dynamic from 'next/dynamic';
const PieChartComp = dynamic(() => import('../components/PieChart'), { ssr: false });

export default function PersonalityPage() {
  const router = useRouter();
  const { personality } = router.query;
  const info = data.find(p => p.key === personality);
  if (!info) return <p className="p-4">Personality not found.</p>;

  return (
    <div className="p-4 max-w-md mx-auto">
      <Link href="/"><a className="text-blue-500 underline">← Back to Portal</a></Link>
      <h1 className="text-2xl font-bold mb-2 mt-4">{info.name} Dashboard</h1>
      <PieChartComp data={info.projects} />
      <ul className="list-disc ml-6 mt-4">
        {info.projects.map(proj => (
          <li key={proj.name} className="mb-2">
            <strong>{proj.name}</strong>: {proj.status}{proj.link && (
              <a href={proj.link} target="_blank" rel="noopener noreferrer" className="underline ml-1">View</a>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
